idea-plains-hq03-001 / sha256:94c9959eaa7e976cc0d3fd39210a3789fe928f937b500900d8dd592a51169d1d

Extract at repository root on the implementation branch. Restore original project resources using pcg/WORKSPACE.md. Original game assets and official Godot binary are referenced, not duplicated here.

Playable scene: pcg/manual_review/implementation/revision-060-final-v1/idea-plains-hq03-001/playable/demo.tscn
Run with the official Godot 4.7.2:
pcg/toolchain/Godot_v4.7.2-stable_linux.x86_64 --path pcg/prototype/godot "$PWD/pcg/manual_review/implementation/revision-060-final-v1/idea-plains-hq03-001/playable/demo.tscn" -- --case 0
Add --replay for actual recorded input playback; omit for manual control. --case N selects another included direction.

Read pcg/manual_review/implementation/revision-060-final-v1/idea-plains-hq03-001/qualification.json for exact FULL/partial/failed scope. A fixed playable sample does not certify untested initial states, mirrors, closures or production approval.
