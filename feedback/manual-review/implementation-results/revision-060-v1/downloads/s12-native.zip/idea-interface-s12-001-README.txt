idea-interface-s12-001 / sha256:c0c0d7573e9ddf42681e19433325058c9c8e7f000f690e6207c913b491d19dd2

Extract at repository root on the implementation branch. Restore original project resources using pcg/WORKSPACE.md. Original game assets and official Godot binary are referenced, not duplicated here.

Playable scene: pcg/manual_review/implementation/revision-060-final-v1/idea-interface-s12-001/playable/demo.tscn
Run with the official Godot 4.7.2:
pcg/toolchain/Godot_v4.7.2-stable_linux.x86_64 --path pcg/prototype/godot "$PWD/pcg/manual_review/implementation/revision-060-final-v1/idea-interface-s12-001/playable/demo.tscn" -- --case 0
Add --replay for actual recorded input playback; omit for manual control. --case N selects another included direction.

Read pcg/manual_review/implementation/revision-060-final-v1/idea-interface-s12-001/qualification.json for exact FULL/partial/failed scope. A fixed playable sample does not certify untested initial states, mirrors, closures or production approval.
