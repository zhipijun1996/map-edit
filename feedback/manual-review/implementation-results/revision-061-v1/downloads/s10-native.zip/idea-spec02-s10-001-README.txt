idea-spec02-s10-001 / sha256:0f6dc21ed04b996082548b16856841672a93b9fea3514548792cb7b41c0ad4a7

Extract at repository root on the implementation branch. Restore original project resources using pcg/WORKSPACE.md. Original game assets and official Godot binary are referenced, not duplicated here.

Playable scene: pcg/manual_review/implementation/revision-061-final-v1/idea-spec02-s10-001/playable/demo.tscn
Run with the official Godot 4.7.2:
pcg/toolchain/Godot_v4.7.2-stable_linux.x86_64 --path pcg/prototype/godot "$PWD/pcg/manual_review/implementation/revision-061-final-v1/idea-spec02-s10-001/playable/demo.tscn" -- --case 0
Add --replay for actual recorded input playback; omit for manual control. --case N selects another included direction.

Read pcg/manual_review/implementation/revision-061-final-v1/idea-spec02-s10-001/qualification.json for exact FULL/partial/failed scope. A fixed playable sample does not certify untested initial states, mirrors, closures or production approval.
