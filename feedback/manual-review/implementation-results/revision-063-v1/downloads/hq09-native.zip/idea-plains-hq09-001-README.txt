idea-plains-hq09-001 / sha256:313fc0c711815b19e726360dbb0f6b4aabd4e4b21c90aba33a7bc5c939f2cff4

Extract at the root of the implementation branch. Restore original project
resources with pcg/WORKSPACE.md; official engine and game assets are referenced.

Playable scene: pcg/manual_review/implementation/revision-063-final-v1/idea-plains-hq09-001/playable/demo.tscn
pcg/toolchain/Godot_v4.7.2-stable_linux.x86_64 --path pcg/prototype/godot "$PWD/pcg/manual_review/implementation/revision-063-final-v1/idea-plains-hq09-001/playable/demo.tscn" -- --case 0

Omit --replay for manual control. Add --replay to replay actual recorded inputs.
--case N selects another included direction. Read qualification.json for the
exact FULL/partial/failed scope. Playable success does not imply qualification.
Human playtest, arbitrary entry states, mirrors and production approval UNKNOWN.
