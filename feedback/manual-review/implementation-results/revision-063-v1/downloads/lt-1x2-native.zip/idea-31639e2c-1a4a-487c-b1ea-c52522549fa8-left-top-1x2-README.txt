idea-31639e2c-1a4a-487c-b1ea-c52522549fa8-left-top-1x2 / sha256:1d5fdf9e4b2aa8ce9ca7146d75f9caac79965dd83034131295ec244949809469

Extract at the root of the implementation branch. Restore original project
resources with pcg/WORKSPACE.md; official engine and game assets are referenced.

Playable scene: pcg/manual_review/implementation/revision-063-final-v1/idea-31639e2c-1a4a-487c-b1ea-c52522549fa8-left-top-1x2/playable/demo.tscn
pcg/toolchain/Godot_v4.7.2-stable_linux.x86_64 --path pcg/prototype/godot "$PWD/pcg/manual_review/implementation/revision-063-final-v1/idea-31639e2c-1a4a-487c-b1ea-c52522549fa8-left-top-1x2/playable/demo.tscn" -- --case 0

Omit --replay for manual control. Add --replay to replay actual recorded inputs.
--case N selects another included direction. Read qualification.json for the
exact FULL/partial/failed scope. Playable success does not imply qualification.
Human playtest, arbitrary entry states, mirrors and production approval UNKNOWN.
