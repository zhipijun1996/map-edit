idea-31639e2c-1a4a-487c-b1ea-c52522549fa8-left-top-2x1 / sha256:8315ca17760b09df75cb1ea052a585078d01cbea69f8373340e90838fc49710c

Extract at the root of the implementation branch. Restore original project
resources with pcg/WORKSPACE.md; official engine and game assets are referenced.

Playable scene: pcg/manual_review/implementation/revision-063-final-v1/idea-31639e2c-1a4a-487c-b1ea-c52522549fa8-left-top-2x1/playable/demo.tscn
pcg/toolchain/Godot_v4.7.2-stable_linux.x86_64 --path pcg/prototype/godot "$PWD/pcg/manual_review/implementation/revision-063-final-v1/idea-31639e2c-1a4a-487c-b1ea-c52522549fa8-left-top-2x1/playable/demo.tscn" -- --case 0

Omit --replay for manual control. Add --replay to replay actual recorded inputs.
--case N selects another included direction. Read qualification.json for the
exact FULL/partial/failed scope. Playable success does not imply qualification.
Human playtest, arbitrary entry states, mirrors and production approval UNKNOWN.
