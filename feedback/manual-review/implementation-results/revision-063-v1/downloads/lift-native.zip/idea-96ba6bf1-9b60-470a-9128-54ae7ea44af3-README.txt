idea-96ba6bf1-9b60-470a-9128-54ae7ea44af3 / sha256:b1c25284b6c9691744e2069c655ca4c4470e295f9849528d8992459e331944d6

Extract at the root of the implementation branch. Restore original project
resources with pcg/WORKSPACE.md; official engine and game assets are referenced.

Playable scene: pcg/manual_review/implementation/revision-063-final-v1/idea-96ba6bf1-9b60-470a-9128-54ae7ea44af3/playable/demo.tscn
pcg/toolchain/Godot_v4.7.2-stable_linux.x86_64 --path pcg/prototype/godot "$PWD/pcg/manual_review/implementation/revision-063-final-v1/idea-96ba6bf1-9b60-470a-9128-54ae7ea44af3/playable/demo.tscn" -- --case 0

Omit --replay for manual control. Add --replay to replay actual recorded inputs.
--case N selects another included direction. Read qualification.json for the
exact FULL/partial/failed scope. Playable success does not imply qualification.
Human playtest, arbitrary entry states, mirrors and production approval UNKNOWN.
