idea-spec02-s04-001 / sha256:3d5d4b164083bf52a544dd4299c58e6dd74f474fafc32f78fc6b760acbdebc4f

Extract at the root of the implementation branch. Restore original project
resources with pcg/WORKSPACE.md; official engine and game assets are referenced.

Playable scene: pcg/manual_review/implementation/revision-063-final-v1/idea-spec02-s04-001/playable/demo.tscn
pcg/toolchain/Godot_v4.7.2-stable_linux.x86_64 --path pcg/prototype/godot "$PWD/pcg/manual_review/implementation/revision-063-final-v1/idea-spec02-s04-001/playable/demo.tscn" -- --case 0

Omit --replay for manual control. Add --replay to replay actual recorded inputs.
--case N selects another included direction. Read qualification.json for the
exact FULL/partial/failed scope. Playable success does not imply qualification.
Human playtest, arbitrary entry states, mirrors and production approval UNKNOWN.
