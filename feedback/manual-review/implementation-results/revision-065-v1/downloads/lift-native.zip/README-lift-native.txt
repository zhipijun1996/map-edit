Extract at repository root. Restore original assets and officialGodot4.7.2 per pcg/WORKSPACE.md.
Scene: pcg/manual_review/implementation/revision-066-final-v1/idea-96ba6bf1-9b60-470a-9128-54ae7ea44af3/playable/demo.tscn
Run official Godot with --path pcg/prototype/godot <scene> -- --case 0. Omit --replay for manual play; add --replay for actual input replay.
Human playtest/production approval UNKNOWN.
