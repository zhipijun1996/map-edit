Extract at repository root. Restore original assets and officialGodot4.7.2 per pcg/WORKSPACE.md.
Scene: feedback/manual-review/implementation-results/revision-065-v1/fixtures/missed-boarding-wait-chest-v2/playable/demo.tscn
Run official Godot with --path pcg/prototype/godot <scene> -- --case 0. Omit --replay for manual play; add --replay for actual input replay.
Human playtest/production approval UNKNOWN.
